#include <map>
#include <regex>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <sstream>
#include <string>
using namespace std;

#ifdef _WIN32
#include <io.h>
#include <direct.h>
#define access _access
#define mkdir _mkdir
#else
#include <fcntl.h>
#include <sys/io.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#endif

#include "gencode.h"

#define USE_FUNC_PROT_HASH 0
#define USE_FUNC_NAME_HASH 1

///

static string tplcontent = "# this, only for java\n# default directory/package is mpc\n\nPACKAGE_BEG\n/*\n * may be some declaration here.\n */\npackage net.platon.vm.mpc;\n\nimport net.platon.vm.proto.Mpctype.*;\nimport net.platon.vm.sdk.client.Data;\nimport net.platon.vm.sdk.client.ErrorCode;\nimport net.platon.vm.sdk.client.IIInterface;\nimport net.platon.vm.sdk.client.InputRequestPara;\nimport net.platon.vm.sdk.client.MpcCallbackInterface;\n\nimport java.util.HashMap;\n\nPACKAGE_END\n\nCOMMENT_BEG\n/**\n * Attention! This file was auto-generated, you just need to implement the \"TODO SECTIONS\".\n * The class name \"IRNAME\" is just to named this file, you can rename \"IRNAME\" what you like.\n * More details ref \"IRNAME-README.TXT\".\n * <p>\n * DIGEST:\n * <p>\nIRDIGEST */\n COMMENT_END\n\nIR_FUNC_INTERFACE_BEG\n        put(\"mpc_f_IRFUNCHASH_IRFUNCPOSX\", new IRNAME_IRFUNCPROTA_IRFUNCPOSX());\nIR_FUNC_INTERFACE_END\n\nABSTRACT_BASE_BEG\ninterface mpc_ii_IRHASH extends IIInterface {\n}\n\npublic class IRNAME implements mpc_ii_IRHASH {\n    private HashMap<String, MpcCallbackInterface> funcInterfaces = new HashMap<String, MpcCallbackInterface>() {{IR_FUNC_INTERFACES    }};\n\n    public MpcCallbackInterface getInstance(String instance_hash) {\n        if (funcInterfaces.containsKey(instance_hash)) {\n            return funcInterfaces.get(instance_hash);\n        }\n        return null;\n    }\n\n    public HashMap<String, MpcCallbackInterface> getInstances() {\n        return funcInterfaces;\n    }\n\n    abstract class MpcCallbackBase_IRHASH implements MpcCallbackInterface {\n        public abstract byte[] inputImpl(final InputRequestPara para);\n\n        public byte[] input(final InputRequestPara para) {\n            // TODO: do what you want to do, before call inputImpl\n            return inputImpl(para);\n        }\n\n        public void error(final InputRequestPara para, ErrorCode error) {\n            // TODO: do what you want to do\n        }\n\n        public void result(final InputRequestPara para, final byte[] data) {\n            // TODO: do what you want to do\n        }\n    }\n\n    abstract class mpc_i_IRHASH extends MpcCallbackBase_IRHASH {\n    }\n    CONTENT_FUNC_ABSTRACT\n    CONTENT_FUNC_EXTENDS\n}\nABSTRACT_BASE_END\n\nFUNC_ABSTRACT_BEG\n    abstract class mpc_f_IRFUNCHASH_IRFUNCPOSX extends mpc_i_IRHASH {\n    }\nFUNC_ABSTRACT_END\n\nFUNC_EXTENDS_BEG\n    /**\n     * IRFUNCPROT\n     */\n    final class IRNAME_IRFUNCPROTA_IRFUNCPOSX extends mpc_f_IRFUNCHASH_IRFUNCPOSX {\n        public byte[] inputImpl(final InputRequestPara para) {\n            // TODO: assemble data\n            RETTYPE ret_value = DATADEFAULTVALUE;\n            \n            return Data.RETVALUEFUNC(ret_value);\n        }\n    }\nFUNC_EXTENDS_END\n\n\nREADME_BEG\n/*\n * may be some declaration here.\n */\nTHIS FILE IS AUTO-GENERATED!\n\nDIGEST:\n/**\nIRDIGEST */\n\nIN GENERAL, YOU JUST NEED TO IMPLEMENT THE \"TODO SECTION\" IN IRNAME.java.\n\nYou can rename \"IRNAME.java\" to any you like, but do not change the md5-string in that .java file.\n\nWhen you implement \"inputImpl\", you can do some work before, log or store the request info,\nin the MpcCallbackBasexx.\n\ntodo......\n\nREADME_END\n";

static string outputdir;
static string digest;
///
int gen_cs(const IR& ir);
int gen_go(const IR& ir);
int gen_cpp(const IR& ir);
int gen_lua(const IR& ir);
int gen_php(const IR& ir);
int gen_java(const IR& ir);
int gen_python(const IR& ir);
int gen_nodejs(const IR& ir);
///


bool makedirs(const std::string& dirpath) {
	string path(dirpath);
	path = regex_replace(path, regex("\\\\"), "/");

	std::string folder_builder;
	std::string sub;
	sub.reserve(path.size());
	for (auto it = path.begin(); it != path.end(); ++it) {
		const char c = *it;
		sub.push_back(c);
		if (c == '/' || it == path.end() - 1) {
			folder_builder.append(sub);
			if (0 != access(folder_builder.c_str(), 0)) {
#ifdef  _WIN32
				if (0 != mkdir(folder_builder.c_str())) {
#else
				if (0 != mkdir(folder_builder.c_str(), 0755)) {
#endif
					return false;
				}
			}
			sub.clear();
		}
	}
	return true;
}



string print_digest(const IR& ir) {
	stringstream sss;
	ostream::fmtflags oldflags = sss.flags();
	sss.setf(ios::left);

	sss << " * IR NAME: " << ir.name
		<< endl << " * IR HASH: " << ir.hash
		<< endl << " * <p>" << endl;
	sss << " * "; sss.width(34); sss << "IR FUNC HASH(MD5)";
	sss.width(16); sss << "IR FUNC NAME";
	sss << "IR FUNC PROT" << endl;
	for (auto ir_func : ir.funcs) {
		sss << " * "; sss.width(34);
#if USE_FUNC_PROT_HASH
		sss << ir_func.hash;
#else
		sss << ir_func.hash2;
#endif
		sss.width(16); sss << ir_func.name;
		sss << ir_func.prot << endl;
	}
	/*
	**	IR NAME: IR1
	**	IR HASH: 1291be25871314f67f4e779f1946ea3b
	**
	**	IR FUNC HASH(MD5)                 IR FUNC NAME    IR FUNC PROT
	**	c34bb37739a6a758afb1c726ee9719c2  add             MPCInteger32 add(MPCInteger32, MPCInteger32)
	**	3e7eacd3b10bfb32bd431f3647f0147f  sub             MPCInteger32 sub(MPCInteger32, MPCInteger32)
	**
	*/
	sss.flags(oldflags);

	return sss.str();
}

int gen_all(IR &ir, string outdir/* = "./"*/)
{
	outputdir = outdir + string("/code/");
	if (!makedirs(outdir)) {
		std::cerr << "can not make output directory [" << outputdir << "]!" << endl;
		return -1;
	}

	ir.name = "IR_" + ir.name;
	ir.name = regex_replace(ir.name, regex("[^a-zA-Z0-9_]"), "_");

	//
	digest = print_digest(ir);
	cout << "digest:\n" << digest << endl;

	//
	if (gen_java(ir) != 0) {
		cerr << "gen java failed" << endl;
		return -1;
	}

	return 0;
}


static string gp_package;
static string gp_comment;
static string gp_ir_func_interface;
static string gp_abstract_base;
static string gp_func_abstract;
static string gp_func_extends;

static string gp_readme;

int getTplFile() {

	///
	match_results<std::string::iterator> results;
#define gen_pattern(X) string(#X"_BEG([\\s\\S]*?)"#X"_END")
#define get_content(v,X) do { \
	if (regex_search(tplcontent.begin(), tplcontent.end(), results, regex(gen_pattern(X)))) { \
		v = results[1].str();\
	}} while (0)

	get_content(gp_package, PACKAGE);
	get_content(gp_comment, COMMENT);
	get_content(gp_ir_func_interface, IR_FUNC_INTERFACE);
	get_content(gp_abstract_base, ABSTRACT_BASE);
	get_content(gp_func_abstract, FUNC_ABSTRACT);
	get_content(gp_func_extends, FUNC_EXTENDS);
	get_content(gp_readme, README);
#undef gen_pattern
#undef get_content

	return 0;
}

void putResult(const string& filename, const string& content) {
	ofstream ofile(filename);
	if (ofile.good()) {
		ofile.write(content.c_str(), content.length());
		ofile.close();
	}
}

string getRetType(const string& type) {
	if (type == "bool") return "boolean";
	else return type;
}

string getDataType(const string& type) {
	if (type == "bool") return "Bool";
	if (type == "int") return "Int32";
	if (type == "long") return "Int64";
	if (type == "float") return "Float";
	if (type == "double") return "Double";
	else return type;
}

string getDefaultValue(const string& type) {
	if (type == "bool") return "false";
	if (type == "int") return "0";
	if (type == "long") return "0";
	if (type == "float") return "0.0f";
	if (type == "double") return "0.0";
	if (type == "MPCInteger32") return "MPCInteger32.newBuilder().setI32(0).build()";
	if (type == "MPCFloat") return "MPCFloat.newBuilder().setF(0.0f).build()";
	else return "0";
}
int gen_java(const IR& ir) {
	string java_outputdir = outputdir + "java/";
	makedirs(java_outputdir);
	if (0 != getTplFile()) { return -1; }

	string content_res;
	content_res += gp_package;
	content_res += gp_comment;
	content_res += gp_abstract_base;

	regex rfunchash("IRFUNCHASH");
	regex rfuncposx("IRFUNCPOSX");
	regex rfuncintf("IR_FUNC_INTERFACES");

	string s_instances("");
	string s_abstractf("");
	string s_extendsfs("");
	string temp;
	for (auto func : ir.funcs) {
#if USE_FUNC_PROT_HASH
		string func_hash = func.hash;
#else // USE_FUNC_NAME_HASH
		string func_hash = func.hash2;
#endif
		temp = gp_ir_func_interface;
		temp = regex_replace(temp, rfunchash, func_hash);
		temp = regex_replace(temp, rfuncposx, "01");
		s_instances += temp;
		temp = gp_ir_func_interface;
		temp = regex_replace(temp, rfunchash, func_hash);
		temp = regex_replace(temp, rfuncposx, "02");
		s_instances += temp;

		temp = gp_func_abstract;
		temp = regex_replace(temp, rfunchash, func_hash);
		temp = regex_replace(temp, rfuncposx, "01");
		s_abstractf += temp;
		temp = gp_func_abstract;
		temp = regex_replace(temp, rfunchash, func_hash);
		temp = regex_replace(temp, rfuncposx, "02");
		s_abstractf += temp;


		string arg_types[3];
		{
			string prot = func.prot;
			match_results<std::string::iterator> results;
			if (regex_search(prot.begin(), prot.end(), results, regex("\\((.*), *(.*)\\)"))) {
				if (results.size() != 3) {
					cerr << "error results.size(): " << results.size() << endl;
					return -1;
				}
				arg_types[0] = results[0].str();
				arg_types[1] = results[1].str();
				arg_types[2] = results[2].str();
			}
			else {
				cerr << "error prot: " << prot << endl;
				return -1;
			}
		}

		///
		temp = gp_func_extends;
		temp = regex_replace(temp, rfunchash, func_hash);
		temp = regex_replace(temp, rfuncposx, "01");
		temp = regex_replace(temp, regex("RETVALUEFUNC"), getDataType(arg_types[1]));
		temp = regex_replace(temp, regex("DATADEFAULTVALUE"), getDefaultValue(arg_types[1]));
		temp = regex_replace(temp, regex("RETTYPE"), getRetType(arg_types[1]));

		s_extendsfs += temp;
		temp = gp_func_extends;
		temp = regex_replace(temp, rfunchash, func_hash);
		temp = regex_replace(temp, rfuncposx, "02");
		temp = regex_replace(temp, regex("RETVALUEFUNC"), getDataType(arg_types[2]));
		temp = regex_replace(temp, regex("DATADEFAULTVALUE"), getDefaultValue(arg_types[2]));
		temp = regex_replace(temp, regex("RETTYPE"), getRetType(arg_types[2]));
		s_extendsfs += temp;
		///

		temp = func.prot;
		temp = regex_replace(temp, regex("[\\(,]"), "_");
		temp = regex_replace(temp, regex("[\\) ]"), "");
		s_extendsfs = regex_replace(s_extendsfs, regex("IRFUNCPROTA"), temp);
		s_abstractf = regex_replace(s_abstractf, regex("IRFUNCPROTA"), temp);
		s_instances = regex_replace(s_instances, regex("IRFUNCPROTA"), temp);

		s_extendsfs = regex_replace(s_extendsfs, regex("IRFUNCPROT"), func.prot);
	}
	s_instances = regex_replace(s_instances, regex("\n\n"), "\n");

	content_res = regex_replace(content_res, regex("CONTENT_FUNC_ABSTRACT"), s_abstractf);
	content_res = regex_replace(content_res, regex("CONTENT_FUNC_EXTENDS"), s_extendsfs);

	content_res = regex_replace(content_res, rfuncintf, s_instances);
	content_res = regex_replace(content_res, regex("IRHASH"), ir.hash);
	content_res = regex_replace(content_res, regex("IRNAME"), ir.name);
	content_res = regex_replace(content_res, regex("IRDIGEST"), digest);


	putResult(java_outputdir + ir.name + ".java", content_res);


	gp_readme = regex_replace(gp_readme, regex("IRDIGEST"), digest);
	gp_readme = regex_replace(gp_readme, regex("IRNAME"), ir.name);
	putResult(java_outputdir + ir.name + "-README.TXT", gp_readme);

	return 0;
}

int gen_cs(const IR& ir) { return 0; }
int gen_go(const IR& ir) { return 0; }
int gen_cpp(const IR& ir) { return 0; }
int gen_lua(const IR& ir) { return 0; }
int gen_php(const IR& ir) { return 0; }
int gen_python(const IR& ir) { return 0; }
int gen_nodejs(const IR& ir) { return 0; }

