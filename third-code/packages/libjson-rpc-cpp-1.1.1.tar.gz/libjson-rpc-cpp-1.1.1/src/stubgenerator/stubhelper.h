/*************************************************************************
 * libjson-rpc-cpp
 *************************************************************************
 * @file    stubhelper.h
 * @date    01.05.2013
 * @author  Peter Spiess-Knafl <dev@spiessknafl.at>
 * @license See attached LICENSE.txt
 ************************************************************************/

#ifndef STUBHELPER_H
#define STUBHELPER_H

#include <fstream>
#include <string>


#endif // STUBHELPER_H
